# ShotLab 🏀

**Offseason Basketball Development Platform**

A mobile-first web app for basketball coaches and players to track drills, log shots, manage events, and compete head-to-head.

## Features

- **Drill Tracking** — Log scores on customizable drills (form shooting, free throws, catch & shoot, ball handling, mid-range, 3-pointers)
- **Shot Tracker** — Daily shot logging with heat maps, running totals, and streaks
- **Head-to-Head Duels** — Challenge teammates and compare scores
- **Strength & Conditioning** — Track S&C session attendance with leaderboards
- **Program Events** — RSVP system with attendance tiers (Iron → Gold → Diamond → Elite)
- **Coach Dashboard** — Manage drills, roster, events, and view team pulse
- **Share Cards** — Auto-generated workout completion cards
- **Report Cards** — Season-long performance summaries with badges
- **Dark/Light Theme** — Full theme support

## Quick Start

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

Output goes to `dist/`. A pre-built `dist/index.html` is also included for direct deployment.

## Deploy to GitHub Pages

**Option A — Use the pre-built dist:**
1. Push this repo to GitHub
2. Settings → Pages → Source: "Deploy from branch"
3. Branch: `main`, Folder: `/dist`
4. Live at `https://<user>.github.io/<repo>/`

**Option B — Build from source:**
```bash
npm install && npm run build
```
Then deploy the `dist/` folder.

## File Structure

```
shotlab/
├── index.html            # Vite entry point
├── package.json
├── vite.config.js
├── src/
│   ├── main.jsx          # React root mount
│   └── App.jsx           # Entire app (single-file architecture)
├── public/
│   └── logo.png          # ShotLab logo
├── dist/
│   └── index.html        # Pre-built standalone (no build step needed)
├── .gitignore
├── LICENSE
└── README.md
```

## Browser Support

Chrome 60+ · Safari 12+ (iOS 12+) · Firefox 55+ · Edge 79+

## License

MIT
